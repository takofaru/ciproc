"use client"

import {
  Background,
  Controls,
  MiniMap,
  ReactFlow,
} from "reactflow"

import "reactflow/dist/style.css"
import { useEditorStore } from "@/stores/editor-store"
import { nodeTypes } from "@/lib/graph/node-registry"
import { useGraphStore } from "@/stores/graph-store"

const initialNodes = [
  {
    id: "1",
    type: "imageInput",
    position: { x: 100, y: 100 },
    data: {
      label: "Image Input",
    },
  },
  {
    id: "2",
    type: "brightness",
    position: { x: 400, y: 100 },
    data: {
      label: "Brightness",
    },
  },
]

const initialEdges = [
  {
    id: "e1-2",
    source: "1",
    target: "2",
  },

]

export function NodeEditor() {

  const {
    nodes,
    edges,
    onNodesChange,
    onEdgesChange,
    onConnect,
  } = useGraphStore()
  
  const setSelectedNode =
    useEditorStore(
      (state) => state.setSelectedNode,
    )


  return (
    <div className="editor-panel h-full">
      <ReactFlow
        nodes={initialNodes}
        edges={initialEdges}
        nodeTypes={nodeTypes}
        fitView
        onNodeClick={(_, node) =>
          setSelectedNode(node)
      }
      >
        <Background />
        <MiniMap />
        <Controls />
      </ReactFlow>
    </div>
  )
}