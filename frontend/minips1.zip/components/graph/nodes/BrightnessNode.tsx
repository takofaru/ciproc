import { BaseNode } from "./BaseNode"

export function BrightnessNode() {
  return (
    <BaseNode title="Brightness">
      <div className="flex flex-col gap-2">
        <label className="text-sm text-zinc-400">Value</label>

        <input type="range" min="0" max="100" />
      </div>
    </BaseNode>
  )
}