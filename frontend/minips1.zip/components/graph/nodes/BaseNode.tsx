import { Handle, Position } from "reactflow"

interface Props {
  title: string
  children?: React.ReactNode
}

export function BaseNode({ title, children }: Props) {
  return (
    <div className="node-container">
      <Handle type="target" position={Position.Left} />

      <div className="node-header">{title}</div>

      <div className="node-content">{children}</div>

      <Handle type="source" position={Position.Right} />
    </div>
  )
}