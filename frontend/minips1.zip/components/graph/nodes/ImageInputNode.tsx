import { BaseNode } from "./BaseNode"

export function ImageInputNode() {
  return (
    <BaseNode title="Image Input">
      <button className="editor-button">
        Upload Image
      </button>
    </BaseNode>
  )
}