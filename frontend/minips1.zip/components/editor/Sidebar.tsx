"use client"

import { nanoid } from "nanoid"

import { useGraphStore } from "@/stores/graph-store"

const modules = [
  {
    type: "brightness",
    label: "Brightness",
  },

  {
    type: "imageInput",
    label: "Image Input",
  },
]

export function Sidebar() {
  const nodes = useGraphStore(
    (state) => state.nodes,
  )

  const setNodes = useGraphStore(
    (state) => state.setNodes,
  )

  const addNode = (type: string) => {
    setNodes([
      ...nodes,

      {
        id: nanoid(),

        type,

        position: {
          x: Math.random() * 400,
          y: Math.random() * 400,
        },

        data: {},
      },
    ])
  }

  return (
    <aside className="editor-panel">
      <div className="panel-header">
        Modules
      </div>

      <div className="panel-body flex flex-col gap-2">
        {modules.map((module) => (
          <button
            key={module.type}
            className="editor-button text-left"
            onClick={() =>
              addNode(module.type)
            }
          >
            {module.label}
          </button>
        ))}
      </div>
    </aside>
  )
}