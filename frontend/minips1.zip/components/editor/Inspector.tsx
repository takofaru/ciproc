"use client"

import { useEditorStore } from "@/stores/editor-store"
import { useCanvasStore } from "@/stores/canvas-store"

export function Inspector() {
  const selectedNode = useEditorStore(
    (state: any) => state.selectedNode,
  )

  const zoom = useCanvasStore(
    (state: any) => state.zoom,
  )

  const setZoom = useCanvasStore(
    (state: any) => state.setZoom,
  )

  return (
    <aside className="editor-panel">
      <div className="panel-header">
        Inspector
      </div>

      <div className="panel-body">
        {!selectedNode ? (
          <p className="text-zinc-500">
            No node selected
          </p>
        ) : (
          <div className="flex flex-col gap-4">
            <div>
              <p className="text-sm text-zinc-400">
                Node Type
              </p>

              <p className="font-medium">
                {selectedNode.type}
              </p>
            </div>

            <div>
              <p className="text-sm text-zinc-400">
                Node ID
              </p>

              <p className="text-xs break-all">
                {selectedNode.id}
              </p>
            </div>
          </div>
        )}
      </div>

      <div>
        <p className="text-sm text-zinc-400 mb-2">
          Canvas Zoom
        </p>

        <input
          type="range"
          min="0.5"
          max="3"
          step="0.1"
          value={zoom}
          onChange={(e) =>
            setZoom(Number(e.target.value))
          }
          className="w-full"
        />
      </div>
    </aside>
  )
}