export function Statusbar() {
  return (
    <footer className="panel mx-2 mb-2 px-3 flex items-center text-sm text-zinc-400">
      Ready
    </footer>
  )
}
