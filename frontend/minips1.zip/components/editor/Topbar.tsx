export function TopBar() {
  return (
    <header className="panel m-2 flex items-center justify-between px-4">
      <div className="flex items-center gap-4">
        <h1 className="font-semibold">
          Mini Photoshop
        </h1>

        <button className="editor-button">
          Import Image
        </button>
      </div>

      <div className="flex items-center gap-2">
        <button className="editor-button">
          Save
        </button>

        <button className="editor-button">
          Export
        </button>
      </div>
    </header>
  )
}
