"use client"

import Image from "next/image"

import { useCanvasStore } from "@/stores/canvas-store"

export function CanvasPreview() {
  const image = useCanvasStore(
    (state: any) => state.image,
  )

  const zoom = useCanvasStore(
    (state: any) => state.zoom,
  )

  return (
    <section className="editor-panel flex items-center justify-center overflow-hidden">
      <div className="canvas-stage">
        {image ? (
          <Image
            src={image}
            alt="Preview"
            width={900}
            height={700}
            style={{
              transform: `scale(${zoom})`,
            }}
            className="object-contain transition-transform duration-150"
          />
        ) : (
          <p className="text-zinc-500">
            No Image Loaded
          </p>
        )}
      </div>
    </section>
  )
}