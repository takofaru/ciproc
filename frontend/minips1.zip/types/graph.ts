import {
  Edge,
  Node,
  NodeChange,
  EdgeChange,
  Connection,
} from "reactflow"

export type EditorNodeData = {
  label?: string
}

export type EditorNode = Node<EditorNodeData>

export type EditorEdge = Edge

export type EditorNodeChange = NodeChange

export type EditorEdgeChange = EdgeChange

export type EditorConnection = Connection