import type { EditorNode } from "@/types/graph"

import { BrightnessNode } from "@/components/graph/nodes/BrightnessNode"
import { ImageInputNode } from "@/components/graph/nodes/ImageInputNode"
import { NodeTypes } from "reactflow"

export const nodeTypes: NodeTypes = {
  brightness: BrightnessNode,
  imageInput: ImageInputNode,
}