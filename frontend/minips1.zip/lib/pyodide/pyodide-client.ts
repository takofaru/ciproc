let worker: Worker | null = null

export function getPyodideWorker(): Worker {
  if (!worker) {
    worker = new Worker(
      new URL(
        "../../workers/pyodide.worker.ts",
        import.meta.url,
      ),
    )
  }

  return worker
}