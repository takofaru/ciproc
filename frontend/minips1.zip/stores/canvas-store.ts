import { create } from "zustand"

interface CanvasStore {
  image: string | null

  zoom: number

  setImage: (
    image: string | null,
  ) => void

  setZoom: (
    zoom: number
  ) => void
}

export const useCanvasStore = create<CanvasStore>((set) => ({
  image: null,

  zoom: 1,

  setImage: (image) =>
    set({
      image,
    }),

  setZoom: (zoom) =>
    set({
      zoom,
    }),
}))