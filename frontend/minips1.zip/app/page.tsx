import Link from "next/link";

export default function HomePage() {
  return (
    <main className="home-page">
      <div className="home-card">
        <h1 className="home-title">
          Mini Photoshop Ciprog
        </h1>

        <p className="home-description">
          Modular node-based image editor.
        </p>

        <Link href="/editor" className="editor-button">
          Open Editor 
        </Link>
      </div>
    </main>
  );
}
