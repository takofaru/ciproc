"use client"

import { useEffect } from "react"

import { nanoid } from "nanoid"

import { EditorLayout } from "@/components/editor/EditorLayout"

import { useGraphStore } from "@/stores/graph-store"

import type { EditorNode } from "@/types/graph"

export default function EditorPage() {

  const initialNodes: EditorNode[] = []

  const setNodes = useGraphStore(
    (state) => state.setNodes,
  )

  useEffect(() => {
    setNodes([
      {
        id: nanoid(),
        type: "imageInput",
        position: {
          x: 100,
          y: 100,
        },
        data: {},
      },

      {
        id: nanoid(),
        type: "brightness",
        position: {
          x: 400,
          y: 100,
        },
        data: {},
      },
    ])
  }, [setNodes])
  
  return <EditorLayout />
}